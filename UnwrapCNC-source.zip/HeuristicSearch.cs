using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace UnwrapCNC;

internal static class HeuristicSearch
{
    internal record Result(List<List<FastNest.Position>> Sheets, double InitialArea, int InitialSheets,
        int CpuWorkers, int GpuWorkers, int Attempts);

    internal static Result Run(FastNest.Item[] items, double width, double height, double gap,
        int attempts, bool useGpu)
    {
        using var session = new Session(items, useGpu);
        return session.Run(width, height, gap, attempts);
    }

    internal sealed class Session : IDisposable
    {
        private readonly FastNest.Item[] items;
        private readonly List<CudaContours> devices = new();
        private readonly Stopwatch timer = new();
        private readonly double seconds;
        private int hasSolution;

        internal bool Expired => seconds > 0 && timer.Elapsed.TotalSeconds >= seconds;

        internal Session(FastNest.Item[] items, bool useGpu, double seconds = 0)
        {
            this.items = items;
            this.seconds = seconds;
            if (!useGpu) return;

            for (int index = 0; index < 32; index++)
            {
                var device = new CudaContours(index);
                if (!device.Available)
                {
                    device.Dispose();
                    break;
                }
                try { device.Prepare(items); }
                catch (System.Runtime.InteropServices.ExternalException)
                {
                    device.Dispose();
                    continue;
                }
                devices.Add(device);
            }
        }

        public void Dispose()
        {
            foreach (var device in devices) device.Dispose();
            devices.Clear();
        }

        internal Result Run(double width, double height, double gap, int attempts)
        {
            timer.Start();
            bool guaranteeFirst = Volatile.Read(ref hasSolution) == 0;
            int completed = 0;
            int cpuWorkers = Math.Min(attempts, Math.Max(1, Math.Min(8, Environment.ProcessorCount - 1)));
            var gate = new object();
            var baselineOrder = items.OrderByDescending(item => item.Area).ToArray();
            var eliteOrder = baselineOrder;
            List<List<FastNest.Position>> best = null;
            double bestArea = double.PositiveInfinity;
            double initialArea = 0;
            int initialSheets = 0;
            int next = -1;

            Parallel.For(0, cpuWorkers + devices.Count, worker =>
            {
                CudaContours gpu = worker < devices.Count ? devices[worker] : null;
                gpu?.Activate();
                while (true)
                {
                    int iteration = Interlocked.Increment(ref next);
                    if (iteration >= attempts || Expired && !(guaranteeFirst && iteration == 0))
                        return;

                    var random = new Random(1701 + iteration * 7919);
                    FastNest.Item[] order;
                    lock (gate) order = (FastNest.Item[])eliteOrder.Clone();
                    if (iteration == 0)
                        order = baselineOrder;
                    else if (iteration % 4 == 0)
                        order = items.OrderByDescending(item => item.Area * (0.25 + random.NextDouble())).ToArray();
                    else
                    {
                        int swaps = 1 + iteration % Math.Max(1, order.Length / 3);
                        for (int move = 0; move < swaps; move++)
                        {
                            int first = random.Next(order.Length);
                            int second = random.Next(order.Length);
                            (order[first], order[second]) = (order[second], order[first]);
                        }
                    }

                    List<List<FastNest.Position>> candidate;
                    try
                    {
                        candidate = FastNest.Pack(order, width, height, gap, iteration % 2 != 0, gpu,
                            guaranteeFirst && iteration == 0 ? null : () => Expired);
                    }
                    catch (OperationCanceledException) { return; }

                    Interlocked.Increment(ref completed);
                    Volatile.Write(ref hasSolution, 1);
                    double area = FastNest.Area(candidate);
                    lock (gate)
                    {
                        if (iteration == 0)
                        {
                            initialArea = area;
                            initialSheets = candidate.Count;
                        }
                        if (best == null || candidate.Count < best.Count ||
                            candidate.Count == best.Count && area < bestArea)
                        {
                            best = candidate;
                            bestArea = area;
                            eliteOrder = order;
                        }
                    }
                }
            });
            return new Result(best, initialArea, initialSheets, cpuWorkers, devices.Count, completed);
        }
    }
}
