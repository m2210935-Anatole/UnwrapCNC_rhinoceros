using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Rhino;
using Rhino.Commands;
using Rhino.DocObjects;
using Rhino.Geometry;
using System.Globalization;
using Eto.Forms;
using Rhino.Input.Custom;
using Rhino.PlugIns;

[assembly: Guid("DF62080B-A04E-49D9-AE67-3DCECC4A6E8B")]
[assembly: System.Reflection.AssemblyTitle("UnwrapCNC")]
[assembly: System.Reflection.AssemblyVersion("4.1.0.0")]

namespace UnwrapCNC;

public sealed class UnwrapCNCPlugin : PlugIn { }

public sealed class UnwrapCNCCommand : Rhino.Commands.Command
{
    public override string EnglishName => "UnwrapCNC";

    private record Part(Guid Source, Curve[] Loops, double Area);
    private record Shape(Curve Outline, Transform Transform, double Width, double Height);
    private record Placement(Part Part, Shape Shape, Curve Outline, double X, double Y);
    private record PackItem(Part Part, Shape[] Shapes);
    private record Face(BrepFace Surface, Plane Plane, double Area);

    protected override Result RunCommand(RhinoDoc doc, RunMode mode)
    {
        bool english = Settings.GetBool("EnglishInterface", false);
        string T(string russian, string translated) => english ? translated : russian;
        double units = RhinoMath.UnitScale(UnitSystem.Millimeters, doc.ModelUnitSystem);
        double tol = doc.ModelAbsoluteTolerance;
        var labels = new[] { T("Толщина материала", "Material thickness"), T("Допуск по толщине ±", "Thickness tolerance ±"), T("Ширина листа", "Sheet width"),
            T("Высота листа", "Sheet height"), T("Зазор между деталями", "Part spacing"), T("Отступ от края листа", "Sheet margin") };
        var keys = new[] { "ThicknessMm", "ToleranceMm", "SheetWidthMm", "SheetHeightMm", "GapMm", "MarginMm" };
        var defaults = new[] { 18d, 0.2, 2440, 1220, 5, 10 };
        var legacy = PlugIn.CommandSettings("CncNestRecovery");
        var fields = keys.Select((key, i) => new TextBox
        {
            Text = (Settings.GetDouble(key, legacy?.GetDouble(key, defaults[i]) ?? defaults[i]) * units).ToString("G15", CultureInfo.CurrentCulture),
            Width = 135
        }).ToArray();
        var attemptsField = new NumericStepper
        {
            MinValue = 1, MaxValue = 128, DecimalPlaces = 0,
            Value = Math.Clamp(Settings.GetInteger("PackingAttempts", 8), 1, 128)
        };
        var timeField = new NumericStepper
        {
            MinValue = 0, MaxValue = 600, DecimalPlaces = 1,
            Value = Math.Clamp(Settings.GetDouble("SearchSeconds", 10), 0, 600)
        };
        var rotationField = new DropDown { DataStore = new[] { "5°", "15°", "30°", "90°" } };
        int savedRotation = Settings.GetInteger("RotationStep", 5);
        int[] rotationSteps = { 5, 15, 30, 90 };
        rotationField.SelectedIndex = Math.Max(0, Array.IndexOf(rotationSteps, savedRotation));
        var gpuField = new CheckBox
        {
            Text = T("Использовать GPU (CUDA)", "Use GPU (CUDA)"),
            Checked = Settings.GetBool("UseGpu", true)
        };
        var oppositeFace = new CheckBox
        {
            Text = T("Использовать обратную сторону", "Use opposite face"),
            Checked = Settings.GetBool("OppositeFace", legacy?.GetBool("OppositeFace", false) ?? false)
        };
        var next = new Button { Text = T("Выбрать детали", "Select parts") };
        var cancel = new Button { Text = T("Отмена", "Cancel") };
        var error = new Label { TextColor = Eto.Drawing.Colors.Firebrick };
        var language = new DropDown { DataStore = new[] { "Русский", "English" }, SelectedIndex = english ? 1 : 0 };
        var translatedLabels = new List<(Label Control, Func<string> Text)>();
        Label LocalLabel(Func<string> text)
        {
            var label = new Label { Text = text(), VerticalAlignment = VerticalAlignment.Center };
            translatedLabels.Add((label, text));
            return label;
        }
        var layout = new DynamicLayout { Padding = new Eto.Drawing.Padding(16), Spacing = new Eto.Drawing.Size(10, 8) };
        layout.AddRow(new Label { Text = "Язык / Language" }, language);
        layout.AddRow(LocalLabel(() => T($"Единицы текущей модели: {doc.ModelUnitSystem}", $"Model units: {doc.ModelUnitSystem}")));
        for (int i = 0; i < fields.Length; i++)
        {
            int index = i;
            layout.AddRow(LocalLabel(() => labels[index]), fields[i]);
        }
        layout.AddRow(LocalLabel(() => T("Количество попыток (1–128)", "Packing attempts (1–128)")), attemptsField);
        layout.AddRow(LocalLabel(() => T("Шаг поворота (крупнее — быстрее)", "Rotation step (larger is faster)")), rotationField);
        layout.AddRow(LocalLabel(() => T("Время поиска, с (0 — без лимита)", "Search time, seconds (0 = unlimited)")), timeField);
        layout.AddRow(gpuField);
        layout.AddRow(oppositeFace);
        layout.AddRow(error);
        layout.AddRow(null, cancel, next);
        using var dialog = new Dialog<bool>
        {
            Title = T("UnwrapCNC — параметры раскладки", "UnwrapCNC — Packing settings"),
            Resizable = false,
            Content = layout,
            DefaultButton = next,
            AbortButton = cancel
        };

        language.SelectedIndexChanged += (_, _) =>
        {
            english = language.SelectedIndex == 1;
            Settings.SetBool("EnglishInterface", english);
            labels = new[]
            {
                T("Толщина материала", "Material thickness"),
                T("Допуск по толщине ±", "Thickness tolerance ±"),
                T("Ширина листа", "Sheet width"), T("Высота листа", "Sheet height"),
                T("Зазор между деталями", "Part spacing"), T("Отступ от края листа", "Sheet margin")
            };
            foreach (var item in translatedLabels) item.Control.Text = item.Text();
            dialog.Title = T("UnwrapCNC — параметры раскладки", "UnwrapCNC — Packing settings");
            next.Text = T("Выбрать детали", "Select parts");
            cancel.Text = T("Отмена", "Cancel");
            oppositeFace.Text = T("Использовать обратную сторону", "Use opposite face");
            gpuField.Text = T("Использовать GPU (CUDA)", "Use GPU (CUDA)");
            error.Text = "";
        };
        var values = new double[fields.Length];
        cancel.Click += (_, _) => dialog.Close(false);
        next.Click += (_, _) =>
        {
            for (int i = 0; i < fields.Length; i++)
            {
                string text = fields[i].Text.Trim().Replace(',', '.');
                double minimum = i == 0 || i == 2 || i == 3 ? tol : 0;
                if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out values[i]) &&
                    double.IsFinite(values[i]) && values[i] >= minimum)
                    continue;
                error.Text = T($"Проверьте поле «{labels[i]}».", $"Check the {labels[i]} field.");
                fields[i].Focus();
                return;
            }
            if (2 * values[5] + tol >= Math.Min(values[2], values[3]))
            {
                error.Text = T("Отступы занимают весь лист.", "Margins leave no usable sheet area.");
                fields[5].Focus();
                return;
            }
            dialog.Close(true);
        };

        if (!dialog.ShowModal(Rhino.UI.RhinoEtoApp.MainWindowForDocument(doc))) return Result.Cancel;
        int passCount = (int)attemptsField.Value;
        double searchSeconds = timeField.Value;
        Settings.SetDouble("SearchSeconds", searchSeconds);
        int rotationStep = rotationSteps[rotationField.SelectedIndex];
        Settings.SetInteger("RotationStep", rotationStep);
        bool useGpu = gpuField.Checked == true;
        Settings.SetInteger("PackingAttempts", passCount);
        Settings.SetBool("UseGpu", useGpu);
        bool opposite = oppositeFace.Checked == true;
        for (int i = 0; i < values.Length; i++) Settings.SetDouble(keys[i], values[i] / units);
        Settings.SetBool("OppositeFace", opposite);
        double thickness = values[0], tolerance = values[1], width = values[2];
        double height = values[3], gap = values[4], margin = values[5];

        using var selection = new GetObject();
        selection.SetCommandPrompt(T("Выберите замкнутые полиповерхности или экструзии", "Select closed polysurfaces or extrusions"));
        selection.GeometryFilter = ObjectType.Brep | ObjectType.Extrusion;
        selection.SubObjectSelect = false;
        selection.EnablePreSelect(false, true);
        selection.GetMultiple(1, 0);
        if (selection.CommandResult() != Result.Success) return selection.CommandResult();

        var parts = new List<Part>();
        for (int i = 0; i < selection.ObjectCount; i++)
        {
            var obj = selection.Object(i);
            var brep = obj.Brep() ?? (obj.Geometry() as Extrusion)?.ToBrep();
            var part = Extract(obj.ObjectId, brep, thickness, tolerance, tol, opposite);
            if (part == null)
                RhinoApp.WriteLine(T($"Пропущен {obj.ObjectId}: не найдена пара плоских сторон заданной толщины или корректный контур.", $"Skipped {obj.ObjectId}: no valid outline or pair of planar faces matching the thickness."));
            else
                parts.Add(part);
        }

        var items = new List<PackItem>();
        foreach (var part in parts)
        {
            var variants = Enumerable.Range(0, 360 / rotationStep).Select(i => Rotate(part.Loops[0], i * rotationStep * Math.PI / 180))
                .Where(s => s.Width <= width - 2 * margin && s.Height <= height - 2 * margin).ToArray();
            if (variants.Length == 0)
                RhinoApp.WriteLine(T($"Пропущен {part.Source}: деталь не помещается на лист при проверенных углах.", $"Skipped {part.Source}: the part does not fit the sheet at the tested angles."));
            else
                items.Add(new PackItem(part, variants));
        }
        int placed = items.Count;
        if (placed == 0) return Result.Nothing;

        var timer = System.Diagnostics.Stopwatch.StartNew();
        double approximation = Math.Max(tol, Math.Min(width, height) / 5000);
        double proxyTolerance = Math.Max(tol, Math.Min(width, height) / 2000);
        int sourceVertices = 0, proxyVertices = 0;
        var fastItems = items.Select((item, index) => new FastNest.Item(index,
            item.Shapes.Select(shape =>
            {
                using var polyline = shape.Outline.ToPolyline(approximation, 0.1, 0, 0);
                if (polyline == null || !polyline.TryGetPolyline(out var points))
                    throw new InvalidOperationException(T("Не удалось подготовить контур.", "Could not prepare the outline."));
                var vertices = points.Take(points.Count - 1).ToArray();
                var polygon = new FastNest.Polygon(vertices.Select(p => p.X).ToArray(),
                    vertices.Select(p => p.Y).ToArray(), shape.Width, shape.Height);
                var proxy = ProxyGeometry.Simplify(polygon, proxyTolerance);
                sourceVertices += polygon.X.Length;
                proxyVertices += proxy.X.Length;
                return proxy;
            }).ToArray(), item.Part.Area)).ToArray();

        RhinoApp.WriteLine(T($"Прокси: {sourceVertices} → {proxyVertices} вершин. Параллельный поиск...", $"Proxy: {sourceVertices} → {proxyVertices} vertices. Searching in parallel..."));
        using var searchSession = new HeuristicSearch.Session(fastItems, useGpu, searchSeconds);
        var search = searchSession.Run(width - 2 * margin, height - 2 * margin,
            gap + 2 * (approximation + proxyTolerance) + 2 * tol, passCount);
        var best = search.Sheets;
        double initialArea = search.InitialArea;
        int initialSheets = search.InitialSheets;
        double bestArea;
        RhinoApp.WriteLine(T($"Потоков CPU: {search.CpuWorkers}; устройств CUDA: {search.GpuWorkers}; попыток: {search.Attempts}.", $"CPU workers: {search.CpuWorkers}; CUDA devices: {search.GpuWorkers}; attempts: {search.Attempts}."));
        if (best.Count == 1)
        {
            var compact = ShrinkCanvas.Run(fastItems, best, width - 2 * margin, height - 2 * margin,
                gap + 2 * (approximation + proxyTolerance) + 2 * tol, passCount, useGpu,
                positions => ValidatePositions(positions, items, gap, tol), message => RhinoApp.WriteLine(message), searchSession, english);
            best = compact.Sheets;
            width = compact.Width + 2 * margin;
            height = compact.Height + 2 * margin;
            RhinoApp.WriteLine(T($"Итоговое полотно с отступами: {width:F2} × {height:F2}. Проверено размеров: {compact.Trials}.", $"Final sheet including margins: {width:F2} × {height:F2}. Sizes tested: {compact.Trials}."));
        }
        else
            RhinoApp.WriteLine(T("Все детали не удалось разместить на одном исходном листе. Сохранена многолистовая раскладка.", "The parts could not fit on one original sheet. A multi-sheet layout was retained."));

        // Exact validation is mandatory before any curves enter the document.
        var sheets = new List<List<Placement>>();
        int repaired = 0;
        foreach (var packed in best)
        {
            var sheet = new List<Placement>();
            sheets.Add(sheet);
            foreach (var position in packed)
            {
                var item = items[position.Item.Id];
                var shape = item.Shapes[position.Rotation];
                double x = position.X + margin, y = position.Y + margin;
                var outline = shape.Outline.DuplicateCurve();
                outline.Translate(x, y, 0);
                if (sheet.Any(p => Conflicts(p, outline, x, y, shape, gap, tol)))
                {
                    outline.Dispose();
                    outline = shape.Outline.DuplicateCurve();
                    outline.Translate(margin, margin, 0);
                    sheets.Add(new() { new Placement(item.Part, shape, outline, margin, margin) });
                    repaired++;
                }
                else sheet.Add(new Placement(item.Part, shape, outline, x, y));
            }
        }
        sheets.RemoveAll(sheet => sheet.Count == 0);
        bestArea = sheets.Sum(OccupiedArea);
        RhinoApp.WriteLine(T($"Расчёт и проверка: {timer.Elapsed.TotalSeconds:F2} с. Исправлено точной проверкой: {repaired}.", $"Packing and validation: {timer.Elapsed.TotalSeconds:F2} s. Exact-check repairs: {repaired}."));        string prefix = $"CNC_{Guid.NewGuid().ToString("N")[..8]}";
        int cut = doc.Layers.Add(new Layer { Name = prefix + "_Cut", Color = System.Drawing.Color.Black });
        int frames = doc.Layers.Add(new Layer { Name = prefix + "_Sheets", Color = System.Drawing.Color.SteelBlue });
        var added = new List<Guid>();
        bool Add(Curve curve, ObjectAttributes attributes)
        {
            Guid id = doc.Objects.AddCurve(curve, attributes);
            if (id == Guid.Empty) return false;
            added.Add(id);
            return true;
        }

        bool success = cut >= 0 && frames >= 0;
        for (int i = 0; success && i < sheets.Count; i++)
        {
            double offset = i * (width + Math.Max(width * 0.05, gap));
            var frame = new Rectangle3d(Plane.WorldXY, new Point3d(offset, 0, 0),
                new Point3d(offset + width, height, 0)).ToNurbsCurve();
            success = Add(frame, new ObjectAttributes { LayerIndex = frames, Name = $"Sheet {i + 1}" });
            foreach (var item in sheets[i])
            {
                for (int j = 0; success && j < item.Part.Loops.Length; j++)
                {
                    using var curve = item.Part.Loops[j].DuplicateCurve();
                    var attrs = new ObjectAttributes { LayerIndex = cut, Name = j == 0 ? "Outer" : "Hole" };
                    attrs.SetUserString("SourceId", item.Part.Source.ToString());
                    attrs.SetUserString("Sheet", (i + 1).ToString());
                    success = curve.Transform(item.Shape.Transform) &&
                        curve.Translate(offset + item.X, item.Y, 0) && Add(curve, attrs);
                }
                if (!success) break;
            }
        }
        if (!success)
        {
            foreach (Guid id in added) doc.Objects.Delete(id, true);
            if (cut >= 0) doc.Layers.Delete(cut, true);
            if (frames >= 0) doc.Layers.Delete(frames, true);
            RhinoApp.WriteLine(T("Не удалось записать раскладку в документ.", "Could not add the layout to the document."));
            return Result.Failure;
        }
        doc.Views.Redraw();
        RhinoApp.WriteLine(T($"До уплотнения (первая попытка): {initialSheets} листов, занятая площадь {initialArea:G8}.", $"Before compaction (first attempt): {initialSheets} sheets, occupied area {initialArea:G8}."));
        RhinoApp.WriteLine(T($"Итог: {sheets.Count} листов, занятая площадь {bestArea:G8} (единицы модели²).", $"Result: {sheets.Count} sheets, occupied area {bestArea:G8} (model units²)."));
        RhinoApp.WriteLine(T($"Размещено деталей: {placed} из {selection.ObjectCount}. Листов: {sheets.Count}. Слои: {prefix}_Cut, {prefix}_Sheets.", $"Placed {placed} of {selection.ObjectCount} parts. Sheets: {sheets.Count}. Layers: {prefix}_Cut, {prefix}_Sheets."));
        return Result.Success;
    }

    private static bool ValidatePositions(List<FastNest.Position> positions, List<PackItem> items, double gap, double tol)
    {
        var checkedParts = new List<Placement>();
        try
        {
            foreach (var position in positions)
            {
                var item = items[position.Item.Id];
                var shape = item.Shapes[position.Rotation];
                var outline = shape.Outline.DuplicateCurve();
                outline.Translate(position.X, position.Y, 0);
                bool conflict = checkedParts.Any(p => Conflicts(p, outline, position.X, position.Y, shape, gap, tol));
                checkedParts.Add(new Placement(item.Part, shape, outline, position.X, position.Y));
                if (conflict) return false;
            }
            return true;
        }
        finally
        {
            foreach (var part in checkedParts) part.Outline.Dispose();
        }
    }
    private static Part Extract(Guid id, Brep brep, double thickness, double tolerance, double tol, bool opposite)
    {
        if (brep == null || !brep.IsValid || !brep.IsSolid) return null;
        var faces = new List<Face>();
        foreach (var face in brep.Faces)
        {
            if (!face.TryGetPlane(out var plane, tol)) continue;
            using var patch = face.DuplicateFace(false);
            using var props = AreaMassProperties.Compute(patch);
            if (props == null || props.Area <= tol * tol) continue;
            var bounds = brep.GetBoundingBox(plane);
            if (Math.Abs(bounds.Min.Z) < Math.Abs(bounds.Max.Z))
                plane.Flip();
            faces.Add(new Face(face, plane, props.Area));
        }
        faces.Sort((a, b) => b.Area.CompareTo(a.Area));
        foreach (var face in faces)
        {
            var bounds = brep.GetBoundingBox(face.Plane);
            double depth = bounds.Max.Z - bounds.Min.Z;
            if (!bounds.IsValid || Math.Abs(depth - thickness) > tolerance + tol || Math.Abs(bounds.Max.Z) > tol)
                continue;
            var other = faces.FirstOrDefault(f =>
                Vector3d.Multiply(f.Plane.ZAxis, face.Plane.ZAxis) < -0.999999 &&
                Math.Abs(face.Plane.DistanceTo(f.Plane.Origin) + depth) <= tol &&
                Math.Abs(f.Plane.DistanceTo(face.Plane.Origin) + depth) <= tol);
            if (other == null) continue;
            var chosen = opposite ? other : face;
            var loops = chosen.Surface.Loops
                .Where(l => l.LoopType == BrepLoopType.Outer || l.LoopType == BrepLoopType.Inner)
                .OrderBy(l => l.LoopType == BrepLoopType.Outer ? 0 : 1)
                .Select(l => l.To3dCurve()).ToArray();
            if (loops.Length == 0 || chosen.Surface.OuterLoop == null) return null;
            var flatten = Transform.PlanarProjection(Plane.WorldXY) *
                Transform.PlaneToPlane(chosen.Plane, Plane.WorldXY);
            if (loops.Any(c => c == null || !c.IsValid || !c.IsClosed || !c.Transform(flatten) || !c.IsValid))
                return null;

            // Start the rotation search with the longest straight boundary segment horizontal.
            var segments = loops[0].DuplicateSegments();
            var edge = segments?.Where(c => c.IsLinear(tol)).OrderByDescending(c => c.GetLength()).FirstOrDefault();
            if (edge != null)
            {
                var direction = edge.PointAtEnd - edge.PointAtStart;
                var align = Transform.Rotation(-Math.Atan2(direction.Y, direction.X), Vector3d.ZAxis, Point3d.Origin);
                foreach (var loop in loops) loop.Transform(align);
            }
            using var outerArea = AreaMassProperties.Compute(loops[0]);
            return new Part(id, loops, outerArea?.Area ?? chosen.Area);
        }
        return null;
    }

    private static Shape Rotate(Curve outline, double angle)
    {
        var rotation = Transform.Rotation(angle, Vector3d.ZAxis, Point3d.Origin);
        var rotated = outline.DuplicateCurve();
        rotated.Transform(rotation);
        var box = rotated.GetBoundingBox(true);
        var shift = Transform.Translation(-box.Min.X, -box.Min.Y, 0);
        rotated.Transform(shift);
        return new Shape(rotated, shift * rotation, box.Max.X - box.Min.X, box.Max.Y - box.Min.Y);
    }

    private static double OccupiedArea(List<Placement> sheet) =>
        (sheet.Max(p => p.X + p.Shape.Width) - sheet.Min(p => p.X)) *
        (sheet.Max(p => p.Y + p.Shape.Height) - sheet.Min(p => p.Y));
    private static bool Conflicts(Placement p, Curve outline, double x, double y, Shape shape, double gap, double tol)
    {
        double padding = gap + tol;
        if (x - p.X - p.Shape.Width >= padding || p.X - x - shape.Width >= padding ||
            y - p.Y - p.Shape.Height >= padding || p.Y - y - shape.Height >= padding)
            return false;

        if (Curve.PlanarClosedCurveRelationship(p.Outline, outline, Plane.WorldXY, tol) != RegionContainment.Disjoint)
            return true;

        return !p.Outline.ClosestPoints(outline, out var a, out var b) || a.DistanceTo(b) < padding;
    }
}



























