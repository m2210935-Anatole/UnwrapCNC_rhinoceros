using System;
using System.Collections.Generic;
using System.Linq;

namespace UnwrapCNC;

internal static class FastNest
{
    internal record Polygon(double[] X, double[] Y, double Width, double Height);
    internal record Item(int Id, Polygon[] Rotations, double Area);
    internal record Position(Item Item, int Rotation, double X, double Y);
    internal static bool Collision(Position a, Polygon b, double x, double y, double gap)
    {
        var p = a.Item.Rotations[a.Rotation];
        if (x >= a.X + p.Width + gap || a.X >= x + b.Width + gap ||
            y >= a.Y + p.Height + gap || a.Y >= y + b.Height + gap) return false;
        if (Inside(p, b.X[0] + x - a.X, b.Y[0] + y - a.Y) ||
            Inside(b, p.X[0] + a.X - x, p.Y[0] + a.Y - y)) return true;
        double limit = gap * gap;
        for (int i = 0; i < p.X.Length; i++)
        {
            int next = (i + 1) % p.X.Length;
            double ax = p.X[i] + a.X, ay = p.Y[i] + a.Y;
            double bx = p.X[next] + a.X, by = p.Y[next] + a.Y;
            for (int j = 0; j < b.X.Length; j++)
            {
                int k = (j + 1) % b.X.Length;
                double cx = b.X[j] + x, cy = b.Y[j] + y;
                double dx = b.X[k] + x, dy = b.Y[k] + y;
                if (Math.Min(ax, bx) > Math.Max(cx, dx) + gap ||
                    Math.Min(cx, dx) > Math.Max(ax, bx) + gap ||
                    Math.Min(ay, by) > Math.Max(cy, dy) + gap ||
                    Math.Min(cy, dy) > Math.Max(ay, by) + gap)
                    continue;
                if ((Cross(bx-ax, by-ay, cx-ax, cy-ay) * Cross(bx-ax, by-ay, dx-ax, dy-ay) <= 0) &&
                    (Cross(dx-cx, dy-cy, ax-cx, ay-cy) * Cross(dx-cx, dy-cy, bx-cx, by-cy) <= 0) &&
                    Math.Max(ax,bx) >= Math.Min(cx,dx) && Math.Max(cx,dx) >= Math.Min(ax,bx) &&
                    Math.Max(ay,by) >= Math.Min(cy,dy) && Math.Max(cy,dy) >= Math.Min(ay,by)) return true;
                if (Distance(ax,ay,cx,cy,dx,dy) < limit || Distance(bx,by,cx,cy,dx,dy) < limit ||
                    Distance(cx,cy,ax,ay,bx,by) < limit || Distance(dx,dy,ax,ay,bx,by) < limit) return true;
            }
        }
        return false;
    }
    private static double Cross(double x, double y, double u, double v) => x*v-y*u;
    private static double Distance(double x,double y,double a,double b,double c,double d)
    {
        double dx=c-a,dy=d-b, length=dx*dx+dy*dy;
        double t=length==0 ? 0 : Math.Clamp(((x-a)*dx+(y-b)*dy)/length,0,1);
        double ex=x-a-t*dx,ey=y-b-t*dy;
        return ex*ex+ey*ey;
    }
    private static bool Inside(Polygon p,double x,double y)
    {
        bool inside=false;
        for(int i=0,j=p.X.Length-1;i<p.X.Length;j=i++)
            if ((p.Y[i]>y)!=(p.Y[j]>y) &&
                x<(p.X[j]-p.X[i])*(y-p.Y[i])/(p.Y[j]-p.Y[i])+p.X[i]) inside=!inside;
        return inside;
    }
    internal static List<List<Position>> Pack(Item[] order,double width,double height,double gap,bool vertical,
        CudaContours gpu = null, Func<bool> shouldStop = null)
    {
        var sheets=new List<List<Position>>();
        foreach(var item in order)
        {
            if (shouldStop?.Invoke() == true) throw new OperationCanceledException();
            Position chosen=null;
            foreach(var sheet in sheets)
            {
                chosen=Find(item,sheet,width,height,gap,vertical,gpu,shouldStop);
                if(chosen==null) continue;
                sheet.Add(chosen);
                break;
            }
            if(chosen==null)
            {
                chosen=Find(item,new(),width,height,gap,vertical,gpu,shouldStop);
                if(chosen==null) throw new InvalidOperationException("Part does not fit.");
                sheets.Add(new(){chosen});
            }
        }
        return sheets;
    }
    private static Position Find(Item item,List<Position> sheet,double width,double height,double gap,bool vertical,
        CudaContours gpu, Func<bool> shouldStop)
    {
        double right=sheet.Select(p=>p.X+p.Item.Rotations[p.Rotation].Width).DefaultIfEmpty(0).Max();
        double top=sheet.Select(p=>p.Y+p.Item.Rotations[p.Rotation].Height).DefaultIfEmpty(0).Max();
        var candidates=new List<(int Rotation,double X,double Y,double Score)>();
        for(int rotation=0;rotation<item.Rotations.Length;rotation++)
        {
            if (shouldStop?.Invoke() == true) throw new OperationCanceledException();
            var shape=item.Rotations[rotation];
            if (shape.Width > width || shape.Height > height) continue;
            var anchors=new HashSet<(double X,double Y)>{(0,0)};
            foreach(var p in sheet)
            {
                var other=p.Item.Rotations[p.Rotation];
                anchors.Add((p.X+other.Width+gap,p.Y));
                anchors.Add((p.X,p.Y+other.Height+gap));
                // Align sampled contour vertices to enter concave free space.
                int strideA=Math.Max(1,other.X.Length/12),strideB=Math.Max(1,shape.X.Length/12);
                for(int a=0;a<other.X.Length;a+=strideA)
                    for(int b=0;b<shape.X.Length;b+=strideB)
                    {
                        double x=p.X+other.X[a]-shape.X[b],y=p.Y+other.Y[a]-shape.Y[b];
                        anchors.Add((x+gap,y));
                        anchors.Add((x,y+gap));
                    }
            }
            // Probe the occupied envelope to find pockets without matching vertices.
            if (sheet.Count > 0)
            {
                double searchWidth = Math.Min(right, width - shape.Width);
                double searchHeight = Math.Min(top, height - shape.Height);
                for (int row = 0; row <= 12; row++)
                    for (int column = 0; column <= 12; column++)
                        anchors.Add((searchWidth * column / 12, searchHeight * row / 12));
            }
            foreach(var point in anchors)
            {
                if(point.X<0||point.Y<0||point.X+shape.Width>width||point.Y+shape.Height>height)continue;
                double w=Math.Max(right,point.X+shape.Width),h=Math.Max(top,point.Y+shape.Height);
                double score=w*h + (vertical ? w/width : h/height)*1e-6;
                candidates.Add((rotation,point.X,point.Y,score));
            }
        }
        candidates.Sort((a,b)=>a.Score.CompareTo(b.Score));
        const int batchSize = 2048;
        for (int start = 0; start < candidates.Count; start += batchSize)
        {
            if (shouldStop?.Invoke() == true) throw new OperationCanceledException();
            int count = Math.Min(batchSize, candidates.Count - start);
            byte[] clear = null;
            if (gpu?.Available == true && sheet.Count > 0 && candidates.Count >= 128)
            {
                try { clear = gpu.Evaluate(item, candidates, sheet, gap, start, count); }
                catch (System.Runtime.InteropServices.ExternalException) { gpu.Dispose(); }
            }
            for (int i = 0; i < count; i++)
            {
                var candidate = candidates[start + i];
                bool fits = clear != null ? clear[i] != 0 :
                    !sheet.Any(p => Collision(p, item.Rotations[candidate.Rotation], candidate.X, candidate.Y, gap));
                if (fits)
                    return new(item, candidate.Rotation, candidate.X, candidate.Y);
            }
        }        return null;
    }
    internal static double Area(List<List<Position>> sheets) => sheets.Sum(sheet =>
        sheet.Max(p=>p.X+p.Item.Rotations[p.Rotation].Width) *
        sheet.Max(p=>p.Y+p.Item.Rotations[p.Rotation].Height));
}







