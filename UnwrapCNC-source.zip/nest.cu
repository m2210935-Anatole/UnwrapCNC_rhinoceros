extern "C" __device__ double cross(double x,double y,double u,double v){return x*v-y*u;}
extern "C" __device__ double distance2(double x,double y,double a,double b,double c,double d){
 double dx=c-a,dy=d-b,l=dx*dx+dy*dy,t=l==0?0:((x-a)*dx+(y-b)*dy)/l;
 t=t<0?0:(t>1?1:t); double ex=x-a-t*dx,ey=y-b-t*dy; return ex*ex+ey*ey;
}
extern "C" __device__ bool inside(const double* p,int n,double x,double y){
 bool v=false; for(int i=0,j=n-1;i<n;j=i++)
 if((p[2*i+1]>y)!=(p[2*j+1]>y) && x<(p[2*j]-p[2*i])*(y-p[2*i+1])/(p[2*j+1]-p[2*i+1])+p[2*i])v=!v;
 return v;
}
extern "C" __global__ void collide(const double* vertices,const int* offsets,const int* counts,
 const double* bounds, const double* candidates,const double* obstacles,int obstacleCount,int candidateCount,double gap,unsigned char* valid){
 int id=blockIdx.x*blockDim.x+threadIdx.x;if(id>=candidateCount)return;
 int shape=(int)candidates[3*id];double x=candidates[3*id+1],y=candidates[3*id+2];
 const double* a=vertices+2*offsets[shape];int na=counts[shape];valid[id]=0;
 for(int s=0;s<obstacleCount;s++){
 int other=(int)obstacles[3*s];double ox=obstacles[3*s+1],oy=obstacles[3*s+2];
 if(x>=ox+bounds[2*other]+gap || ox>=x+bounds[2*shape]+gap ||
    y>=oy+bounds[2*other+1]+gap || oy>=y+bounds[2*shape+1]+gap)continue;
 const double* b=vertices+2*offsets[other];int nb=counts[other];
 if(inside(a,na,b[0]+ox-x,b[1]+oy-y)||inside(b,nb,a[0]+x-ox,a[1]+y-oy))return;
 for(int i=0;i<na;i++){int k=(i+1)%na;
 double ax=a[2*i]+x,ay=a[2*i+1]+y,bx=a[2*k]+x,by=a[2*k+1]+y;
 for(int j=0;j<nb;j++){int l=(j+1)%nb;
 double cx=b[2*j]+ox,cy=b[2*j+1]+oy,dx=b[2*l]+ox,dy=b[2*l+1]+oy;
 if(fmin(ax,bx)>fmax(cx,dx)+gap || fmin(cx,dx)>fmax(ax,bx)+gap ||
    fmin(ay,by)>fmax(cy,dy)+gap || fmin(cy,dy)>fmax(ay,by)+gap)continue;
 if(cross(bx-ax,by-ay,cx-ax,cy-ay)*cross(bx-ax,by-ay,dx-ax,dy-ay)<=0 &&
 cross(dx-cx,dy-cy,ax-cx,ay-cy)*cross(dx-cx,dy-cy,bx-cx,by-cy)<=0 &&
 fmax(ax,bx)>=fmin(cx,dx)&&fmax(cx,dx)>=fmin(ax,bx)&&fmax(ay,by)>=fmin(cy,dy)&&fmax(cy,dy)>=fmin(ay,by))return;
 double g=gap*gap;
 if(distance2(ax,ay,cx,cy,dx,dy)<g||distance2(bx,by,cx,cy,dx,dy)<g||
 distance2(cx,cy,ax,ay,bx,by)<g||distance2(dx,dy,ax,ay,bx,by)<g)return;
 }}
 }valid[id]=1;
}

