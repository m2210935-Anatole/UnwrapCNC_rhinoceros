using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Reflection;

namespace UnwrapCNC;
internal sealed class CudaContours : IDisposable
{
    private IntPtr context, module, kernel;
    private ulong vertices, offsets, counts, bounds;
    private ulong candidateBuffer, obstacleBuffer, resultBuffer;
    private int candidateCapacity, obstacleCapacity, resultCapacity;
    private readonly Dictionary<FastNest.Polygon,int> ids = new();
    internal bool Available => kernel != IntPtr.Zero;
    internal CudaContours(int index=0)
    {
        try {
            Check(cuInit(0)); Check(cuDeviceGet(out int device,index));
            Check(cuCtxCreate_v2(out context,0,device));
            using var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("nest.ptx");
            var data=new byte[stream.Length]; stream.ReadExactly(data);
            Check(cuModuleLoadData(out module,data)); Check(cuModuleGetFunction(out kernel,module,"collide"));
        } catch(Exception e) when(e is ExternalException or DllNotFoundException or EntryPointNotFoundException) { Dispose(); }
    }
    internal void Prepare(FastNest.Item[] items)
    {
        var xy=new List<double>();var starts=new List<int>();var sizes=new List<int>();var dimensions=new List<double>();
        foreach(var item in items) foreach(var polygon in item.Rotations) {
            if (ids.ContainsKey(polygon)) continue;
            dimensions.Add(polygon.Width);
            dimensions.Add(polygon.Height);
            ids.Add(polygon,ids.Count);starts.Add(xy.Count/2);sizes.Add(polygon.X.Length);
            for(int i=0;i<polygon.X.Length;i++){xy.Add(polygon.X[i]);xy.Add(polygon.Y[i]);}
        }
        vertices=Upload(xy.ToArray()); offsets=Upload(starts.ToArray());counts=Upload(sizes.ToArray());bounds=Upload(dimensions.ToArray());
    }
    internal byte[] Evaluate(FastNest.Item item,List<(int Rotation,double X,double Y,double Score)> candidates,
        List<FastNest.Position> sheet,double gap,int start = 0,int count = -1)
    {
        if (count < 0) count = candidates.Count - start;
        var candidateData=new double[count*3];
        for(int i=0;i<count;i++){var c=candidates[start+i];candidateData[3*i]=ids[item.Rotations[c.Rotation]];candidateData[3*i+1]=c.X;candidateData[3*i+2]=c.Y;}
        var obstacleData=new double[sheet.Count*3];
        for(int i=0;i<sheet.Count;i++){var p=sheet[i];obstacleData[3*i]=ids[p.Item.Rotations[p.Rotation]];obstacleData[3*i+1]=p.X;obstacleData[3*i+2]=p.Y;}

        var handles=new List<GCHandle>();
        try {
            EnsureBuffer(ref candidateBuffer, ref candidateCapacity, Buffer.ByteLength(candidateData));
            EnsureBuffer(ref obstacleBuffer, ref obstacleCapacity, Buffer.ByteLength(obstacleData));
            EnsureBuffer(ref resultBuffer, ref resultCapacity, count);
            Write(candidateBuffer, candidateData);
            Write(obstacleBuffer, obstacleData);
            object[] values={new[]{vertices},new[]{offsets},new[]{counts},new[]{bounds},new[]{candidateBuffer},new[]{obstacleBuffer},
                new[]{sheet.Count},new[]{count},new[]{gap},new[]{resultBuffer}};
            var args=new IntPtr[values.Length];
            for(int i=0;i<values.Length;i++){var h=GCHandle.Alloc(values[i],GCHandleType.Pinned);handles.Add(h);args[i]=h.AddrOfPinnedObject();}
            Check(cuLaunchKernel(kernel,(uint)((count+127)/128),1,1,128,1,1,0,IntPtr.Zero,args,IntPtr.Zero));
            var bytes=new byte[count];var pin=GCHandle.Alloc(bytes,GCHandleType.Pinned);
            try{Check(cuMemcpyDtoH_v2(pin.AddrOfPinnedObject(),resultBuffer,(UIntPtr)bytes.Length));}finally{pin.Free();}
            return bytes;
        } finally {
            foreach(var h in handles)h.Free();

        }
    }
    private static void EnsureBuffer(ref ulong buffer, ref int capacity, int required)
    {
        if (buffer != 0 && capacity >= required) return;
        int nextCapacity = Math.Max(required, Math.Max(1024, capacity * 2));
        Check(cuMemAlloc_v2(out ulong replacement, (UIntPtr)nextCapacity));
        if (buffer != 0) cuMemFree_v2(buffer);
        buffer = replacement;
        capacity = nextCapacity;
    }

    private static void Write(ulong buffer, Array data)
    {
        var pin = GCHandle.Alloc(data, GCHandleType.Pinned);
        try { Check(cuMemcpyHtoD_v2(buffer, pin.AddrOfPinnedObject(), (UIntPtr)Buffer.ByteLength(data))); }
        finally { pin.Free(); }
    }

    private static ulong Upload(Array data) {
        int bytes=Buffer.ByteLength(data);Check(cuMemAlloc_v2(out ulong device,(UIntPtr)Math.Max(bytes,1)));
        var pin=GCHandle.Alloc(data,GCHandleType.Pinned);
        try{Check(cuMemcpyHtoD_v2(device,pin.AddrOfPinnedObject(),(UIntPtr)bytes));return device;}
        catch{cuMemFree_v2(device);throw;}finally{pin.Free();}
    }
    public void Dispose(){
        if(context==IntPtr.Zero)return;
        cuCtxSetCurrent(context);
        if(vertices!=0)cuMemFree_v2(vertices);if(offsets!=0)cuMemFree_v2(offsets);if(counts!=0)cuMemFree_v2(counts);
        if (bounds != 0) cuMemFree_v2(bounds);
        if (candidateBuffer != 0) cuMemFree_v2(candidateBuffer);
        if (obstacleBuffer != 0) cuMemFree_v2(obstacleBuffer);
        if (resultBuffer != 0) cuMemFree_v2(resultBuffer);
        if(module!=IntPtr.Zero)cuModuleUnload(module);
        cuCtxDestroy_v2(context);context=module=kernel=IntPtr.Zero;
    }
    internal void Activate(){Check(cuCtxSetCurrent(context));}
    private static void Check(int code){if(code!=0)throw new ExternalException("CUDA error "+code);}
    [DllImport("nvcuda.dll")]private static extern int cuInit(uint flags);
    [DllImport("nvcuda.dll")]private static extern int cuDeviceGet(out int device,int ordinal);
    [DllImport("nvcuda.dll")]private static extern int cuCtxCreate_v2(out IntPtr context,uint flags,int device);
    [DllImport("nvcuda.dll")]private static extern int cuCtxSetCurrent(IntPtr context);
    [DllImport("nvcuda.dll")]private static extern int cuCtxDestroy_v2(IntPtr context);
    [DllImport("nvcuda.dll")]private static extern int cuModuleLoadData(out IntPtr module,byte[] data);
    [DllImport("nvcuda.dll")]private static extern int cuModuleGetFunction(out IntPtr function,IntPtr module,[MarshalAs(UnmanagedType.LPStr)]string name);
    [DllImport("nvcuda.dll")]private static extern int cuModuleUnload(IntPtr module);
    [DllImport("nvcuda.dll")]private static extern int cuMemAlloc_v2(out ulong pointer,UIntPtr bytes);
    [DllImport("nvcuda.dll")]private static extern int cuMemFree_v2(ulong pointer);
    [DllImport("nvcuda.dll")]private static extern int cuMemcpyHtoD_v2(ulong target,IntPtr source,UIntPtr bytes);
    [DllImport("nvcuda.dll")]private static extern int cuMemcpyDtoH_v2(IntPtr target,ulong source,UIntPtr bytes);
    [DllImport("nvcuda.dll")]private static extern int cuLaunchKernel(IntPtr kernel,uint gx,uint gy,uint gz,uint bx,uint by,uint bz,uint shared,IntPtr stream,IntPtr[] arguments,IntPtr extra);
}

