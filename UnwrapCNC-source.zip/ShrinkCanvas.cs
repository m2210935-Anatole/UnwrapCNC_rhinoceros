using System;
using System.Collections.Generic;
using System.Linq;

namespace UnwrapCNC;

internal static class ShrinkCanvas
{
    internal record Result(List<List<FastNest.Position>> Sheets, double Width, double Height, int Trials);
    internal static Result Run(FastNest.Item[] items, List<List<FastNest.Position>> initial,
        double width, double height, double gap, int attempts, bool gpu,
        Func<List<FastNest.Position>,bool> validate, Action<string> progress, HeuristicSearch.Session session = null, bool english = false)
    {
        if (initial.Count != 1) return new(initial,width,height,0);
        using var ownedSession = session == null ? new HeuristicSearch.Session(items, gpu) : null;
        session ??= ownedSession;
        var best = initial;
        int trials = 0;
        // Empty strips can be removed without repacking or changing any clearance.
        if (validate(best[0]))
        {
            width = Math.Min(width, best[0].Max(p => p.X + p.Item.Rotations[p.Rotation].Width));
            height = Math.Min(height, best[0].Max(p => p.Y + p.Item.Rotations[p.Rotation].Height));
        }
        // Each successful step establishes the next starting rectangle.
        foreach (double fraction in new[] { 0.05, 0.02, 0.01 })
        {
            for (int step = 0; step < 6; step++)
            {
                bool improved = false;
                foreach (int axis in new[] { 0, 1 })
                {
                    if (session.Expired) return new(best, width, height, trials);
                    double nextWidth = axis == 0 ? width * (1-fraction) : width;
                    double nextHeight = axis == 1 ? height * (1-fraction) : height;
                    if (items.Any(item => !item.Rotations.Any(p => p.Width <= nextWidth && p.Height <= nextHeight)))
                        continue;
                    if (best[0].All(p => p.X + p.Item.Rotations[p.Rotation].Width <= nextWidth &&
                        p.Y + p.Item.Rotations[p.Rotation].Height <= nextHeight) && validate(best[0]))
                    {
                        width = nextWidth;
                        height = nextHeight;
                        improved = true;
                        continue;
                    }
                    trials++;
                    progress?.Invoke(english ? $"Shrinking sheet: {nextWidth:F2} × {nextHeight:F2}, step {fraction:P0}." : $"Уменьшение полотна: {nextWidth:F2} × {nextHeight:F2}, шаг {fraction:P0}.");
                    var candidate = session.Run(nextWidth,nextHeight,gap,attempts).Sheets;
                    if (candidate == null || candidate.Count != 1 || !validate(candidate[0])) continue;
                    best = candidate;
                    width = nextWidth;
                    height = nextHeight;
                    improved = true;
                }
                if (!improved) break;
            }
        }
        return new(best,width,height,trials);
    }
}




