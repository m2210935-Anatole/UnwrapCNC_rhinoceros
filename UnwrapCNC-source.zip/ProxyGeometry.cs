using System;
using System.Collections.Generic;
using System.Linq;

namespace UnwrapCNC;

internal static class ProxyGeometry
{
    // Split a closed contour into two open chains, then bound deviation from every source vertex.
    internal static FastNest.Polygon Simplify(FastNest.Polygon polygon, double tolerance)
    {
        int count = polygon.X.Length;
        if (count <= 4) return polygon;
        int split = 1;
        double largest = 0;
        for (int i = 1; i < count; i++)
        {
            double dx = polygon.X[i] - polygon.X[0], dy = polygon.Y[i] - polygon.Y[0];
            double distance = dx * dx + dy * dy;
            if (distance > largest) { largest = distance; split = i; }
        }
        var keep = new SortedSet<int> { 0, split };
        var ranges = new Stack<(int Start, int End)>();
        ranges.Push((0, split));
        ranges.Push((split, count));
        double limit = tolerance * tolerance;
        while (ranges.Count > 0)
        {
            var (start, end) = ranges.Pop();
            int a = start % count, b = end % count;
            double dx = polygon.X[b] - polygon.X[a], dy = polygon.Y[b] - polygon.Y[a];
            double length = dx * dx + dy * dy;
            int furthest = -1;
            double maxDistance = limit;
            for (int i = start + 1; i < end; i++)
            {
                int p = i % count;
                double x = polygon.X[p] - polygon.X[a], y = polygon.Y[p] - polygon.Y[a];
                double t = length == 0 ? 0 : Math.Clamp((x * dx + y * dy) / length, 0, 1);
                double ex = x - t * dx, ey = y - t * dy;
                double distance = ex * ex + ey * ey;
                if (distance > maxDistance) { maxDistance = distance; furthest = i; }
            }
            if (furthest < 0) continue;
            keep.Add(furthest % count);
            ranges.Push((start, furthest));
            ranges.Push((furthest, end));
        }
        if (keep.Count < 3) return polygon;
        return new FastNest.Polygon(keep.Select(i => polygon.X[i]).ToArray(),
            keep.Select(i => polygon.Y[i]).ToArray(), polygon.Width, polygon.Height);
    }
}
